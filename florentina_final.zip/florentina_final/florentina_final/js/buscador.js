document.addEventListener("DOMContentLoaded", function () {
    const sugerenciasData = [
        { nombre: "🏠 Inicio", url: "inicio.html" },
        { nombre: "📖 Menú", url: "menu.html" },
        { nombre: "🎯 Misión", url: "quienes-somos.html#mision" },
        { nombre: "🌟 Visión", url: "quienes-somos.html#vision" },
        { nombre: "📞 Contáctanos", url: "contactanos.html" },
        { nombre: "🛒 Hacer un pedido", url: "menu.html" }
    ];

    const input = document.getElementById("buscador");
    const listaResultados = document.getElementById("resultados");
    const contenedorBuscador = document.querySelector(".buscador-navegacion");

    function mostrarSugerencias(filtradas) {
        listaResultados.innerHTML = "";
        
        if (filtradas.length === 0 && input.value.trim() !== "") {
             // Opcional: mostrar "No hay resultados"
            const li = document.createElement("li");
            li.textContent = "No hay resultados";
            listaResultados.appendChild(li);
        } else if (filtradas.length === 0 && input.value.trim() === "") {
            // No mostrar nada si el input está vacío y la lista de sugerencias está vacía
            listaResultados.classList.remove("mostrar");
            return;
        }

        filtradas.forEach(item => {
            const li = document.createElement("li");
            const enlace = document.createElement("a");
            
            enlace.href = item.url;
            enlace.textContent = item.nombre;
            // No necesitas estilos inline aquí, el CSS ya los maneja
            
            li.appendChild(enlace);
            listaResultados.appendChild(li);
        });
        
        // 🔑 CLAVE: Añadir la clase para que el CSS lo haga visible
        listaResultados.classList.add("mostrar"); 
    }

    // Evento de foco: Muestra las sugerencias clave
    input.addEventListener("focus", () => {
        if (input.value.trim() === "") {
            mostrarSugerencias(sugerenciasData);
        } else {
            // Si el foco regresa y ya hay texto, actualiza la búsqueda
            const texto = input.value.toLowerCase().trim();
            const filtrados = sugerenciasData.filter(item =>
                item.nombre.toLowerCase().includes(texto)
            );
            mostrarSugerencias(filtrados);
        }
    });

    // Evento de escritura: Realiza el filtrado dinámico
    input.addEventListener("input", () => {
        const texto = input.value.toLowerCase().trim();
        if (texto === "") {
            // Mostrar las sugerencias clave si se borra todo el texto
            mostrarSugerencias(sugerenciasData);
        } else {
            const filtrados = sugerenciasData.filter(item =>
                item.nombre.toLowerCase().includes(texto)
            );
            mostrarSugerencias(filtrados);
        }
    });

    // Evento de clic en el documento: Ocultar la lista si se hace clic fuera
    document.addEventListener("click", (e) => {
        // Usa el contenedor principal para verificar si el clic fue dentro o fuera
        if (!contenedorBuscador.contains(e.target)) {
            // 🔑 CLAVE: Quitar la clase para que el CSS lo oculte
            listaResultados.classList.remove("mostrar");
        }
    });
});