<?php
// php/db.php

$host = "localhost";       // Servidor de la BD
$user = "root";            // Usuario de MySQL en XAMPP
$pass = "";                // Contraseña (vacía en XAMPP por defecto)
$dbname = "florentina_pagos";  // Nombre de tu base de datos

// Crear conexión
$conn = new mysqli($host, $user, $pass, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("❌ Error de conexión: " . $conn->connect_error);
}

// Opcional: establecer charset
$conn->set_charset("utf8mb4");
?>
