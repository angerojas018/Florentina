<?php
require_once __DIR__ . '/db.php';
// guardar_pago.php
// -----------------
// Ajusta si tu instalación usa otros datos
$servidor   = "localhost";
$usuario    = "root";
$contrasena = "";
$base_datos = "florentina_pagos";

// Conexión
$conn = new mysqli($servidor, $usuario, $contrasena, $base_datos);
if ($conn->connect_errno) {
    http_response_code(500);
    die("Error de conexión: " . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die("Método no permitido.");
}

// Recibir y sanitizar campos de texto
$nombres    = trim($_POST['nombres'] ?? '');
$apellidos  = trim($_POST['apellidos'] ?? '');
$direccion  = trim($_POST['direccion'] ?? '');
$barrio     = trim($_POST['barrio'] ?? '');
$telefono   = trim($_POST['telefono'] ?? '');
$precio_raw = trim($_POST['precio'] ?? '');
$metodo_pago= trim($_POST['metodo_pago'] ?? '');

// Validaciones básicas
$errores = [];
if ($nombres === '') $errores[] = "El nombre es obligatorio.";
if ($apellidos === '') $errores[] = "El apellido es obligatorio.";
if ($direccion === '') $errores[] = "La dirección es obligatoria.";
if ($barrio === '') $errores[] = "El barrio es obligatorio.";
if ($telefono === '') $errores[] = "El teléfono es obligatorio.";
if ($metodo_pago === '') $errores[] = "Seleccione un método de pago.";

// Manejo del comprobante (archivo)
$comprobante_db_path = null; // ruta que guardaremos en DB (si sube archivo)
if (!isset($_FILES['comprobante']) || $_FILES['comprobante']['error'] === UPLOAD_ERR_NO_FILE) {
    $errores[] = "Debe subir el comprobante de pago.";
} else {
    $file = $_FILES['comprobante'];
    // Errores básicos de upload
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errores[] = "Error al subir el archivo (codigo: {$file['error']}).";
    } else {
        // Validaciones: tamaño y tipo
        $maxBytes = 3 * 1024 * 1024; // 3 MB
        if ($file['size'] > $maxBytes) {
            $errores[] = "El comprobante debe ser menor a 3 MB.";
        } else {
            // Permitir extensiones: jpg,jpeg,png,pdf
            $allowed_ext = ['jpg','jpeg','png','pdf'];
            // Obtener extensión real con finfo
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($file['tmp_name']);
            $map = [
                'image/jpeg' => 'jpg',
                'image/png'  => 'png',
                'application/pdf' => 'pdf'
            ];
            if (!isset($map[$mime])) {
                $errores[] = "Tipo de archivo no permitido. Solo JPG, PNG o PDF.";
            } else {
                $ext = $map[$mime];
                // Preparar carpeta uploads (dentro del proyecto)
                $uploads_dir = __DIR__ . '/../uploads';
                if (!is_dir($uploads_dir)) {
                    if (!mkdir($uploads_dir, 0755, true) && !is_dir($uploads_dir)) {
                        $errores[] = "No se pudo crear carpeta de uploads.";
                    }
                }
                // Generar nombre único seguro
                $basename = bin2hex(random_bytes(8)); // 16 chars
                $filename = $basename . '_' . time() . '.' . $ext;
                $target_path = $uploads_dir . '/' . $filename;

                if (empty($errores)) {
                    if (!move_uploaded_file($file['tmp_name'], $target_path)) {
                        $errores[] = "No se pudo mover el archivo subido.";
                    } else {
                        // Guardar ruta relativa para DB (ej: uploads/archivo.pdf)
                        $comprobante_db_path = 'uploads/' . $filename;
                    }
                }
            }
        }
    }
}

// Si hay errores, mostrar y detener
if (!empty($errores)) {
    echo "<h3>Se encontraron errores:</h3><ul>";
    foreach ($errores as $e) {
        echo "<li>" . htmlspecialchars($e) . "</li>";
    }
    echo "</ul><p><a href=\"../pago.html\">Volver</a></p>";
    exit;
}

/*
 * Normalizar precio:
 */
$precio_clean = preg_replace('/[^\d\.,]/u', '', $precio_raw);
if ($precio_clean === '') {
    $precio_float = 0.0;
} else {
    if (strpos($precio_clean, ',') !== false && strpos($precio_clean, '.') !== false) {
        $precio_clean = preg_replace('/\.(?=\d{3}(?:[^\d]|$))/u', '', $precio_clean);
        $precio_clean = str_replace(',', '.', $precio_clean);
    } else {
        if (strpos($precio_clean, ',') !== false) {
            $precio_clean = str_replace(',', '.', $precio_clean);
        } else {
            if (preg_match('/\.\d{3}$/', $precio_clean)) {
                $precio_clean = str_replace('.', '', $precio_clean);
            }
        }
    }
    $precio_float = (float) $precio_clean;
}

// Insertar con prepared statement
$sql = "INSERT INTO pedidos (nombres, apellidos, direccion, barrio, telefono, precio, metodo_pago, comprobante)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    http_response_code(500);
    die("Error en la preparación: " . $conn->error);
}

// Tipos: s s s s s d s s -> 'sssssdss'
$stmt->bind_param('sssssdss', $nombres, $apellidos, $direccion, $barrio, $telefono, $precio_float, $metodo_pago, $comprobante_db_path);

if ($stmt->execute()) {
    $last_id = $stmt->insert_id;
    $stmt->close();
    $conn->close();
    // Mensaje corto (sin redirección)
    echo "✅ Pedido #{$last_id} guardado correctamente.";
    // Opcional: mostrar enlace al comprobante subido (solo para desarrollo)
    // echo "<br>Comprobante: <a href=\"../" . htmlspecialchars($comprobante_db_path) . "\" target=\"_blank\">Ver</a>";
    exit;
} else {
    $err = $stmt->error;
    $stmt->close();
    $conn->close();
    http_response_code(500);
    echo "Error al guardar el pedido: " . htmlspecialchars($err);
    exit;
}
?>
